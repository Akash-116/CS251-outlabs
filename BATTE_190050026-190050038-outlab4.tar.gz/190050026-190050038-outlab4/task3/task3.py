import argparse
from scipy.cluster.vq import kmeans2
from PIL import Image
import numpy as np
import matplotlib
matplotlib.use('pdf')
import matplotlib.pyplot as plt

parser = argparse.ArgumentParser()
parser.add_argument('--input')
parser.add_argument('--k')
parser.add_argument('--output')
args = parser.parse_args()

input = np.asarray(Image.open(args.input))
input_image = input.astype(float).reshape(-1,3)

k = int(args.k)

centroid, label = kmeans2(input_image, k, minit='++')

vfunc = np.vectorize(lambda i: centroid[label[i]], otypes=[np.ndarray])
output = np.vstack(vfunc(np.arange(input_image.shape[0]))).reshape(input.shape).astype(int)

plt.imshow(output)
plt.axis('off')
plt.savefig(args.output, bbox_inches='tight', pad_inches=0)