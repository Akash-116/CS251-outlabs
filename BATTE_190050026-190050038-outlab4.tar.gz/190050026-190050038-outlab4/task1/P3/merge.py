import numpy as np
import csv

input_file_1 = open('mumbai_data.csv', 'r')
input_file_2 = open('mumbai_unlock.csv', 'r')
input_1 = []
input_2 = []
days = []

reader_1 = csv.reader(input_file_1)
reader_2 = csv.reader(input_file_2)
 
head = next(reader_1)

for row in reader_1:
	days.append(row[0])
	input_1.append([int(i) for i in row[1:]])

head = next(reader_2)

for row in reader_2:
	input_2.append([int(i) for i in row[1:]])

input_array_1 = np.array(input_1)
input_array_2 = np.array(input_2)
days_array = np.array(days)
pos_rate_1 = np.array(['%.3f' %i for i in input_array_1[:,1]/input_array_1[:,0]])
pos_rate_2 = np.array(['%.3f' %i for i in input_array_2[:,1]/input_array_2[:,0]])

out_fields = ['Day', 'Infected(Unlock)', 'Infected(Lock)', 'Positivity Rate(Lock)', 'Positivity Rate(Unlock)']

out_array = np.zeros((days_array.size, 4))

out_array[:,0] = input_array_2[:,1]
out_array[:,1] = input_array_1[:,1]
out_array[:,2] = pos_rate_1
out_array[:,3] = pos_rate_2

out_array = np.concatenate((days_array.T.reshape(-1, 1), out_array), axis=1)

output_file = open('info_combine.csv', 'w')

writer = csv.writer(output_file)

writer.writerow(out_fields)

writer.writerows(list(out_array))

input_file_1.close()
input_file_2.close()
output_file.close()