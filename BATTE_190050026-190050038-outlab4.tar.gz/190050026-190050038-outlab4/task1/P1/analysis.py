import numpy as np
import csv

input_file = open('mumbai_data.csv', 'r')
input = []

reader = csv.reader(input_file)

head = next(reader)

for row in reader:
	input.append([int(i) for i in row[1:]])

input_array = np.array(input)

mean = np.mean(input_array, axis=0)

std = np.std(input_array, axis=0)

output = []

output.append(['Field'] + head[1:])
output.append(['Mean'] + ['%.3f' % i for i in mean])
output.append(['Std.Dev.'] + ['%.3f' % i for i in std])

output_array = np.array(output)

for row in output_array.T:
	print("{: >10} {: >10} {: >10}".format(*row))

input_file.close()