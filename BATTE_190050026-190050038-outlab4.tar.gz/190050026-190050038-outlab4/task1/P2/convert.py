import numpy as np
import csv

input_file = open('mumbai_data.csv', 'r')
input = []
days = []

reader = csv.reader(input_file)

head = next(reader)

for row in reader:
	days.append(row[0])
	input.append([int(i) for i in row[1:]])

input_array = np.array(input)
days_array = np.array(days)

out_fields = ['Day', 'Tests per Million', 'Test Positivity rate', 'Recovered', 'Deceased']

out_array = np.concatenate((days_array.T.reshape(-1, 1), input), axis=1)

out_array[:,1] = np.array([int(i) for i in input_array[:,0]/20.4])
out_array[:,2] = np.array(['%.3f' % i for i in input_array[:,1]/input_array[:,0]])

output_file = open('transformed.csv', 'w')

writer = csv.writer(output_file)

writer.writerow(out_fields)

writer.writerows(list(out_array))

input_file.close()
output_file.close()