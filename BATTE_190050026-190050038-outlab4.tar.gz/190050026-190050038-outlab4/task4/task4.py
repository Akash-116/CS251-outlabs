import numpy as np
import matplotlib
matplotlib.use('pdf')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.misc import derivative
import pandas as pd

def b(x):
	return g(abs(x))

def g(x):
	return h(2-x)/(h(2-x)+h(x-1))

def h(x):
	if x>0:
		return np.exp(-1/(x**2))
	else:
		return 0

def sinc(x, y):
	if(x**2+y**2>0):
		return (np.sin(np.sqrt(x**2+y**2)))/(np.sqrt(x**2+y**2))
	else:
		return 1

def fn_plot1d(fn, x_min, x_max, filename):
	x = np.arange(x_min, x_max, (x_max-x_min)*0.01)
	y = np.vectorize(fn)(x)
	plt.figure()
	plt.plot(x, y)
	plt.xlabel('x')
	plt.ylabel(fn.__name__+'(x)')
	plt.title('Plot of y = '+fn.__name__+'(x)')
	plt.savefig(filename)

def fn_plot2d(fn, x_min, x_max, y_min, y_max, filename):
	x = np.arange(x_min, x_max, (x_max-x_min)*0.01).reshape(-1, 1)
	y = np.arange(y_min, y_max, (y_max-y_min)*0.01).reshape(1, -1)
	z = np.vectorize(fn)(x, y)
	ax = plt.figure().add_subplot(1, 1, 1, projection='3d')
	ax.plot_surface(x, y, z)
	ax.set_xlabel('x')
	ax.set_ylabel('y')
	ax.set_zlabel(fn.__name__+'(x,y)')
	plt.title('Plot of z = '+fn.__name__+'(x,y)')
	plt.savefig(filename)

def nth_derivative_plotter(fn, n, x_min, x_max, filename):
	x = np.arange(x_min, x_max, (x_max-x_min)*0.01)
	y = np.vectorize(lambda i:derivative(fn, x0=i, dx=1e-6, n=n))(x)
	plt.figure()
	plt.plot(x, y)
	plt.xlabel('x')
	plt.ylabel(fn.__name__+'^'+str(n)+'(x)')
	plt.title('Plot of y = '+fn.__name__+'^'+str(n)+'(x)')
	plt.savefig(filename)

fn_plot1d(b, -2, 2, 'fn1plot.png')
fn_plot2d(sinc, -1.5*np.pi, 1.5*np.pi, -1.5*np.pi, 1.5*np.pi, 'fnplot2d.png')
for i in range(1,3):
	nth_derivative_plotter(b, i, -2, 2, 'bd_'+str(i)+'.png')