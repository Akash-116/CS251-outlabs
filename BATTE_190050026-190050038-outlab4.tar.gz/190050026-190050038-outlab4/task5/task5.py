import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('pdf')
import matplotlib.pyplot as plt
from scipy import stats

url = 'https://api.covid19india.org/csv/latest/case_time_series.csv'

data = pd.read_csv(url)
start_index = list(data['Date']).index('15 April ')

H = []
deceased_list = list(data['Total Deceased'])

for ind in range(start_index,len(deceased_list)):
	H.append(deceased_list[ind]/deceased_list[ind-1])

y = range(1, len(H)+1)

slope, intercept, r_value, p_value, std_err = stats.linregress(y, H)

print(int((1-intercept)/slope)+1)

plt.scatter(y, H)
plt.plot(y, [i*slope + intercept for i in y], 'r')

plt.ylabel('H(t)')
plt.xlabel('No.of Days from 15 April')
plt.title("Linear Regression on Levitt's Metric")
plt.legend(['Linear fit','Data'])
plt.savefig('covid.png')