import sys
import matplotlib
matplotlib.use('pdf')
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from collections import defaultdict
import argparse


parser = argparse.ArgumentParser()
parser.add_argument('--data')
args = parser.parse_args()

data = pd.read_csv(args.data)

group_data = data.groupby(['instance', 'algorithm', 'epsilon', 'horizon'])

output = {'instance':[], 'algorithm':[], 'epsilon':[], 'horizon':[], 'Regret':[]}

for name,group in group_data:
	output['instance'].append(name[0])
	output['algorithm'].append(name[1])
	output['epsilon'].append(name[2])
	output['horizon'].append(name[3])
	if group['REG'].size>50:
		output['Regret'].append(group['REG'].sample(n=50).mean())
	else:
		output['Regret'].append(group['REG'].mean())

output = pd.DataFrame(output)
legends = []

for index, instance in enumerate(['i-1.txt', 'i-2.txt', 'i-3.txt']):
	plt.figure()
	df = output[output['instance']==instance]

	algs_list = []
	for alg in df['algorithm']:
		if alg not in algs_list:
			algs_list.append(alg)

	for alg in algs_list:
		if alg != 'epsilon-greedy':
			plt.plot(df[df['algorithm']==alg]['horizon'], df[df['algorithm']==alg]['Regret'])
			legends.append(alg)
		else:
			df_1 = df[df['algorithm']=='epsilon-greedy']
			for epsilon in [0.002, 0.02, 0.2]:
				plt.plot(df_1[df_1['epsilon']==epsilon]['horizon'], df_1[df_1['epsilon']==epsilon]['Regret'])
				legends.append('epsilon-greedy with epsilon='+str(epsilon))

	plt.xlabel('horizon')
	plt.ylabel('Regret')
	plt.title('Instance '+str(index+1)+' - both axes in log scale')
	plt.legend(legends)
	plt.xscale('log')
	plt.yscale('log')
	plt.savefig('instance'+str(index+1)+'.png')